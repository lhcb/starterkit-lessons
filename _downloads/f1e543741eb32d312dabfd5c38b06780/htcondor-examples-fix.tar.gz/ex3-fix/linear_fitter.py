import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('inputfile', help='State the location of the input data file', type=str)
parser.add_argument('outputfile', help='State the location of the output plot', type=str)
args = parser.parse_args()

# read data, calculate fit
x, y = np.loadtxt(args.inputfile, usecols=(0,1), unpack=True)
coef = np.polyfit(x, y, 1)
poly = np.poly1d(coef)
r2 = np.sum((poly(x) - np.sum(y)/len(y))**2) / np.sum((y - np.sum(y)/len(y))**2)

# print fit information
print('Fitted a straight line to the data in {0}'.format(args.inputfile))
print('  Gradient:  {0}'.format(poly[0]))
print('  Intercept: {0}'.format(poly[1]))
print('Goodness of fit (r^2): {0}'.format(r2))

# create plot
plt.plot(x,y,'+') # plot data
plt.plot([min(x), max(x)], [np.polyval(poly, min(x)), np.polyval(poly, max(x))], 'k-') # plot fit line
plt.savefig(args.outputfile)
