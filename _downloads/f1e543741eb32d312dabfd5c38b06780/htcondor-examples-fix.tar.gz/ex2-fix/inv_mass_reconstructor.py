import argparse
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('inputfile', help='State the location of the input data file', type=str)
args = parser.parse_args()

PE,PX,PY,PZ = np.loadtxt(args.inputfile, skiprows=1, unpack=True)
inv_mass = np.sqrt(np.sum(PE)**2 - np.sum(PX)**2 - np.sum(PY)**2 - np.sum(PZ)**2)

#print(children)
print(inv_mass)
