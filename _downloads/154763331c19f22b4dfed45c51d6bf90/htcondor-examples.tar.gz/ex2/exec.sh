#!/bin/bash
python inv_mass_reconstructor.py "$@"
