#!/bin/bash
mkdir figures
python linear_fitter.py "$@"
