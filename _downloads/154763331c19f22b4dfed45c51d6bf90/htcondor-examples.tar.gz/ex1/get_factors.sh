#!/bin/bash
factor "$1" | sed -e "s/^$1: //" > "factors_$1.txt"
